fixture skill body ignored
