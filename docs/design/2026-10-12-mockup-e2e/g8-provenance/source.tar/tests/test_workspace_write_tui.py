"""TUI mediation for proposed file writes: offered only when granted, diff first."""
import ast
import asyncio
from pathlib import Path

from isycode.security import ActionRequest
from isycode.workspace_write import WritePreview

SOURCE = Path(__file__).resolve().parents[1] / "src" / "isycode" / "tui.py"


def _owned():
    methods = {}
    sources = {}
    for path in (SOURCE, *sorted(SOURCE.parent.glob("tui_app_*.py"))):
        text = path.read_text(encoding="utf-8")
        module = ast.parse(text)
        for node in module.body:
            if not isinstance(node, ast.ClassDef):
                continue
            if node.name != "TUIApp" and not node.name.endswith("Mixin"):
                continue
            for item in node.body:
                if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    methods[item.name] = item
                    sources[item.name] = text
    return sources, methods


def _segment(name):
    sources, methods = _owned()
    return ast.get_source_segment(sources[name], methods[name])


def test_write_tool_is_offered_only_when_the_write_grant_is_on():
    run_chat = _segment("_run_chat")
    assert "write_active = tools_active and (self._workspace_write_tool_enabled() or self._additional_folder_access(write=True))" in run_chat
    assert "CHAT_WORKSPACE_TOOLS + [EDIT_TOOL, WRITE_TOOL] if write_active" in run_chat
    assert "tools=chat_tools" in run_chat


def test_write_dispatch_rechecks_the_grant_shows_the_diff_and_uses_the_owner():
    dispatch = _segment("_dispatch_write_tool")
    assert dispatch.index("_workspace_write_tool_enabled(root)") < dispatch.index("owner.preview")
    assert dispatch.index("WriteApprovalScreen(preview") < dispatch.index("owner.apply")
    assert "rejected_by_user" in dispatch
    for forbidden in ("write_text", "write_bytes", "open(", "os.replace"):
        assert forbidden not in dispatch


def test_approval_screen_rejects_by_default_and_applies_only_on_the_button(tmp_path):
    from textual.app import App
    from isycode.tui import WriteApprovalScreen

    request = ActionRequest("workspace.files.write", tmp_path, str(tmp_path / "a.txt"), {},
                            execution_owner="workspace_write")
    preview = WritePreview(request, "a.txt", "--- a/a.txt\n+++ b/a.txt\n-x\n+y\n", False, "y\n")
    results = []

    class Host(App):
        def on_mount(self):
            self.push_screen(WriteApprovalScreen(preview), results.append)

    async def scenario(keys):
        async with Host().run_test() as pilot:
            await pilot.pause()
            for key in keys:
                await pilot.press(key)
            await pilot.pause()

    asyncio.run(scenario(["escape"]))
    asyncio.run(scenario(["enter"]))   # focus starts on Reject
    asyncio.run(scenario(["tab", "enter"]))
    assert results == [False, False, True]
